var mongoose = require('mongoose');
var crypto   = require('crypto');
var scheme_kacamata = require('../models/sch_kacamata');

console.log("preparing 2 create database ");

